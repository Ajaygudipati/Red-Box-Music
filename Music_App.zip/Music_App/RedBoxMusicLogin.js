// Page Load Animation
document.addEventListener("DOMContentLoaded", () => {
    const heading = document.getElementById("heading");
    heading.style.opacity = 0;
    heading.style.transform = "translateY(-20px)";
    setTimeout(() => {
        heading.style.transition = "all 1s ease";
        heading.style.opacity = 1;
        heading.style.transform = "translateY(0)";
    }, 300);
});

// Button Ripple Animation
const loginButton = document.querySelector("button");
loginButton.addEventListener("click", (e) => {
    const ripple = document.createElement("span");
    ripple.classList.add("ripple");
    ripple.style.left = `${e.offsetX}px`;
    ripple.style.top = `${e.offsetY}px`;
    loginButton.appendChild(ripple);

    setTimeout(() => {
        ripple.remove();
    }, 600);
});

// Admin Page Song Upload (Example)
if (window.location.pathname.includes("admin.html")) {
    const uploadForm = document.createElement("form");
    uploadForm.innerHTML = `
        <h2>Add Album</h2>
        <input type="text" placeholder="Album Name" required><br>
        <input type="file" id="songFiles" multiple accept="audio/*"><br><br>
        <button type="submit">Upload Album</button>
        <ul id="songList"></ul>
    `;
    document.body.appendChild(uploadForm);

    uploadForm.addEventListener("submit", function (e) {
        e.preventDefault();
        const albumName = this.querySelector("input[type='text']").value;
        const files = this.querySelector("#songFiles").files;
        const songList = this.querySelector("#songList");

        songList.innerHTML = `<h3>${albumName}</h3>`;
        for (let file of files) {
            const li = document.createElement("li");
            li.textContent = file.name;
            songList.appendChild(li);
        }
        alert("Album uploaded (simulated)");
    });
}
